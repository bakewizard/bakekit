# BareBone Plugin for BakeKit

`BareBone` plugin is a simple plugin for [BakeKit CMS](https://github.com/bakewizard/BakeKit) that does nothing. It is a good starting point for creating your own plugins.

## Installation

You can install this plugin via the BakeKit Admin Panel by uploading the plugin zip.
