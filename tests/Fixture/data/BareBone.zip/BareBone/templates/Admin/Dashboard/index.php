<?php $this->assign('page', __('BareBone plugin')); ?>
<div class="card">
    <div class="card-header">
        <div class="card-title"><i class="fa-solid fa-tachometer-alt me-2"></i> <?= __('Dashboard') ?></div>
    </div>
    <div class="card-body">
        BareBone plugin is a simple plugin that does nothing. It is a good starting point for creating your own plugins.
    </div>
</div>