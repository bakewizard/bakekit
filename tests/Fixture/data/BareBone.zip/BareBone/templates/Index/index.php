<div class="card">
    <div class="card-body">
        <p>BareBone plugin is a simple plugin that does nothing. It is a good starting point for creating your own plugins.</p>
    </div>
</div>