<?php

declare(strict_types=1);

namespace BareBone;

use App\Core\CmsPlugin;
use Cake\Core\PluginApplicationInterface;
use Cake\Routing\Route\DashedRoute;
use Cake\Routing\RouteBuilder;

/**
 * BareBone plugin
 */
class BareBonePlugin extends CmsPlugin
{

    protected ?string $name = 'BareBone';
    protected bool $bootstrapEnabled = false;
    protected bool $consoleEnabled = false;
    protected bool $middlewareEnabled = false;
    protected bool $servicesEnabled = false;

    public function routes(RouteBuilder $routes): void
    {
        $routes->plugin($this->name, ['path' => '/bare-bone'], function (RouteBuilder $routes) {
            $routes->connect('/', ['controller' => 'Index']);
            $routes->fallbacks(DashedRoute::class);
        });

        $routes->prefix('Admin', function (RouteBuilder $routes) {
            $routes->plugin($this->name, function (RouteBuilder $routes) {
                $routes->applyMiddleware('auth');
                $routes->connect('/', ['controller' => 'Dashboard']);
                $routes->fallbacks(DashedRoute::class);
            });
        });
    }

}
