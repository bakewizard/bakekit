<?php
declare(strict_types=1);

namespace BareBone\View\Cell;

use App\Attribute\Link;
use App\View\Cell\BlockCell as Cell;

/**
 * Article cell
 */
class ArticleCell extends Cell
{
    /**
     * Displays a list of the most recently published articles.
     *
     * @return void
     */
    #[Link(summary: 'Recent articles', description: 'Recent articles list')]
    public function recent(): void
    {
    }

    /**
     * Displays a list of the most commented articles.
     *
     * @return void
     */
    #[Link(summary: 'Popular articles', description: 'Popular articles list')]
    public function popular(): void
    {
    }
}
