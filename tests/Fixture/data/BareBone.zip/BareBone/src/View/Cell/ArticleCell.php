<?php
declare(strict_types=1);

namespace BareBone\View\Cell;

use App\Attribute\Link;
use App\View\Cell\BlockCell as Cell;

class ArticleCell extends Cell
{
    #[Link(summary: 'Recent articles', description: 'Displays a recent articles list')]
    public function recent()
    {
        $limit = intval($this->block->params['numberOfArticlesToShow'] ?? 5);
        $articles = $this->fetchTable('Blogger.Articles')
            ->find('published')
            ->limit($limit)
            ->orderByDesc('Articles.created')
            ->toArray();
        $this->set(compact('articles'));
    }

    #[Link(summary: 'Popular articles', description: 'Displays a popular articles list')]
    public function popular()
    {
        $limit = intval($this->block->params['numberOfArticlesToShow'] ?? 5);
        $articles = $this->fetchTable('Blogger.Articles')
            ->find('published')
            ->limit($limit)
            ->orderByDesc('Articles.comments_count')
            ->toArray();
        $this->set(compact('articles'));
    }

    public function related()
    {
        $limit = intval($this->block->params['numberOfArticlesToShow'] ?? 5);
        $articles = $this->fetchTable('Blogger.Articles')
            ->find('related', id: intval($this->request->getParam('id')))
            ->limit($limit)
            ->toArray();
        $this->set(compact('articles'));
    }
}
