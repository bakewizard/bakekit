<?php

declare(strict_types=1);

namespace BareBone\Controller;

use Cake\Controller\Controller;
use Cake\Event\EventInterface;
use Cake\View\JsonView;

class AppController extends Controller
{

    public function viewClasses(): array
    {
        return [JsonView::class];
    }

    /**
     * Before render callback.
     *
     * @param \Cake\Event\EventInterface $event The beforeRender event.
     * @return void
     */
    public function beforeRender(EventInterface $event)
    {
        if (!array_key_exists('serialize', $this->viewBuilder()->getOptions()) && in_array($this->request->contentType(), ['application/json', 'application/xml'])) {
            $this->viewBuilder()->setOption('serialize', true);
        }
    }
}
