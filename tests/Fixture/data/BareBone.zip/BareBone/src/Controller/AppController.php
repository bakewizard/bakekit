<?php
declare(strict_types=1);

namespace BareBone\Controller;

use App\Controller\AppController as BaseController;

class AppController extends BaseController
{
}
