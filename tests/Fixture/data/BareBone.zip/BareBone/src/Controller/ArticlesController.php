<?php
declare(strict_types=1);

namespace BareBone\Controller;

use App\Attribute\Link;
use Cake\Core\Configure;
use Cake\Database\Expression\QueryExpression;
use Cake\Database\Query;
use Cake\Utility\Hash;

class ArticlesController extends AppController
{
    public array $paginate = [
        'order' => ['Articles.created' => 'desc'],
    ];

    public function initialize(): void
    {
        parent::initialize();
        $this->paginate['limit'] = Configure::read('Blogger.articlesPerPage', 10);
    }

    #[Link(summary: 'Articles', description: 'List of articles')]
    public function index()
    {
        $articles = $this->paginate($this->Articles->find('published')->contain(['Users']));
        $this->set(compact('articles'));
    }

    #[Link(summary: 'View article', description: 'Single article page', picker: 'Articles')]
    public function view($id = null)
    {
        $article = $this->Articles->findById($id)
            ->find('published')
            ->contain(['Tags', 'Users'])
            ->firstOrFail();
        $this->set('article', $article);
    }

    // No #[Link] — should not appear in getLinks()
    public function category($id) {}
    public function tag($alias = null) {}
    public function search() {}
}
