<?php
declare(strict_types=1);

namespace BareBone\Controller;

use App\Attribute\Link;

/**
 * Articles Controller
 */
class ArticlesController extends AppController
{
    /**
     * Displays a paginated list of published articles.
     *
     * @return void
     */
    #[Link(summary: 'Articles list', description: 'Published articles')]
    public function index(): void
    {
    }

    /**
     * Displays a single published article.
     *
     * @param string|null $id Article id.
     * @return void
     */
    #[Link(summary: 'Single article', description: 'Article details', picker: 'Articles')]
    public function view(?string $id = null): void
    {
    }

    /**
     * Displays articles filtered by category.
     *
     * @param int $id Category id.
     * @return void
     */
    public function category(int $id): void
    {
    }
}
