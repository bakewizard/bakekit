<?php

declare(strict_types=1);

namespace BareBone\Controller;

/**
 * Index Controller
 *
 */
class IndexController extends AppController
{

    public function index()
    {

    }
}
