<?php
declare(strict_types=1);

namespace BareBone\Controller\Admin;

use App\Controller\Admin\AppController as BaseController;

class AppController extends BaseController
{
}
