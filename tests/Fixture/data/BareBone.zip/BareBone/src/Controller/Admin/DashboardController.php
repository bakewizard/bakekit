<?php
declare(strict_types=1);

namespace BareBone\Controller\Admin;

/**
 * Dashboard Controller
 */
class DashboardController extends AppController
{
    /**
     * Displays the plugin dashboard with overview statistics.
     *
     * @return void
     */
    public function index(): void
    {
    }

    /**
     * Displays the plugin settings page.
     *
     * @return void
     */
    public function settings(): void
    {
    }
}
