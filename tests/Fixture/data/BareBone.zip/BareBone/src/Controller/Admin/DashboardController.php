<?php
declare(strict_types=1);

namespace BareBone\Controller\Admin;

use App\Attribute\Resource;
use App\Controller\Admin\AppController;

/**
 * Dashboard Controller
 */
class DashboardController extends AppController
{
    #[Resource(label: 'View dashboard')]
    public function index()
    {
    }

    #[Resource(label: 'Dashboard settings')]
    public function settings()
    {
    }
}
