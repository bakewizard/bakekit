<?php

declare(strict_types=1);

namespace BareBone\Controller\Admin;

use App\Controller\Admin\AppController;
use Cake\Cache\Cache;
use Cake\I18n\FrozenTime;

/**
 * Dashboard Controller
 */
class DashboardController extends AppController
{

    public function index()
    {
        
    }
}
