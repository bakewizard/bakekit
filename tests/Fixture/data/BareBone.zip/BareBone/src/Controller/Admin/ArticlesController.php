<?php
declare(strict_types=1);

namespace BareBone\Controller\Admin;

/**
 * Articles Controller
 */
class ArticlesController extends AppController
{
    /**
     * Displays a paginated list of articles with filtering support.
     *
     * @return void
     */
    public function index(): void
    {
    }

    /**
     * Creates a new article.
     *
     * @return void
     */
    public function add(): void
    {
    }

    /**
     * Edits an existing article.
     *
     * @param string $id Article id.
     * @return void
     */
    public function edit(string $id): void
    {
    }

    /**
     * Deletes an article.
     *
     * @param string $id Article id.
     * @return void
     */
    public function delete(string $id): void
    {
    }
}
