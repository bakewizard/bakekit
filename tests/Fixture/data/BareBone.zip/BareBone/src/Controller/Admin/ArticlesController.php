<?php
declare(strict_types=1);

namespace BareBone\Controller\Admin;

use App\Attribute\Resource;

/**
 * Articles Controller
 */
class ArticlesController extends AppController
{
    #[Resource(label: 'List articles')]
    public function index()
    {
        $query = $this->Articles->find('search', search: $this->request->getQueryParams(), collection: 'backend')
                ->contain(['Users', 'Categories']);

        $articles = $this->paginate($query);

        $this->set(compact('articles'));
    }

    public function view($id = null)
    {
        $article = $this->Articles->get($id);
        $this->set('article', $article);
    }

    #[Resource(label: 'Create an article')]
    public function add()
    {
        $article = $this->Articles->newEmptyEntity();
        if ($this->request->is('post')) {
            $article = $this->Articles->patchEntity($article, $this->request->getData());
            $article->author_id = $this->Authentication->getIdentityData('id');
            if ($this->Articles->save($article)) {
                $this->Flash->success(__('The article has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The article could not be saved. Please, try again.'));
            }
        }
        $tags = $this->Articles->Tags->find('list', limit: 200);
        $categories = $this->Articles->Categories->find('treeList', spacer: '-- ', limit: 200);

        $this->set(compact('article', 'categories', 'tags'));
    }

    #[Resource(label: 'Edit an article')]
    public function edit($id = null)
    {
        $article = $this->Articles->get($id, contain: ['Categories', 'Tags']);

        if ($this->request->is(['patch', 'post', 'put'])) {
            $article = $this->Articles->patchEntity($article, $this->request->getData());
            if ($this->Articles->save($article)) {
                $this->Flash->success(__('The article has been saved.'));
                return $this->redirect(['action' => 'index']);
            } else {
                $this->Flash->error(__('The article could not be saved. Please, try again.'));
            }
        }
        $users = $this->Articles->Users->find('list', limit: 200);
        $tags = $this->Articles->Tags->find('list', limit: 200);
        $categories = $this->Articles->Categories->find('treeList', spacer: '-- ', limit: 200);

        $this->set(compact('article', 'categories', 'tags', 'users'));
    }

    #[Resource(label: 'Delete an article')]
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $article = $this->Articles->get($id);
        if ($this->Articles->delete($article)) {
            $this->Flash->success(__('The article has been deleted.'));
        } else {
            $this->Flash->error(__('The article could not be deleted. Please, try again.'));
        }
        return $this->redirect(['action' => 'index']);
    }
}
